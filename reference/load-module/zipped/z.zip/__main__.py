import mymod

print('Hello there')

mymod.myf()
