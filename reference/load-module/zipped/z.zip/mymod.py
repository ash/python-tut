def myf():
    print('myf')
